export interface ITodo {
    todoId?: string,
    description?: string,
    deadline?: string,
    completed?: boolean,
    filepath?: string
}
