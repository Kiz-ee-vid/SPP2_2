import React from 'react';
import TodosPage from "./pages/TodosPage";
import {Container} from "react-bootstrap";

const App: React.FC = () => {
    return (
        <Container className="min-vh-100 shadow p-3 pt-5 bg-white rounded">
            <TodosPage/>
        </Container>
    )
}

export default App;
