import {createApi, fetchBaseQuery} from "@reduxjs/toolkit/dist/query/react";
import {CreateTodoParams, FetchAllTodosParams, FetchAllTodosResult, UpdateTodoParams} from "../models/todo/todo.types";
import {ITodo} from "../models/todo/ITodo";


export const todoAPI = createApi({
    reducerPath: 'todoAPI',
    baseQuery: fetchBaseQuery({baseUrl: '/api/'}),
    tagTypes: ['Todo'],
    endpoints: (build) => ({
        fetchAllTodos: build.query<FetchAllTodosResult, FetchAllTodosParams>({
            query: (params: FetchAllTodosParams) => ({
                url: '/todos',
                params
            }),
            providesTags: result => ['Todo']
        }),
        createTodo: build.mutation<ITodo, CreateTodoParams>({
            query: (params: CreateTodoParams) => ({
                url: '/todos',
                method: 'POST',
                body: params.body
            }),
            invalidatesTags: ['Todo']
        }),
        updateTodo: build.mutation<ITodo, UpdateTodoParams>({
            query: (params: UpdateTodoParams) => ({
                url: `/todos/${params.todoId}`,
                method: 'PUT',
                body: params.body
            }),
            invalidatesTags: ['Todo']
        }),
        deleteTodo: build.mutation<ITodo, ITodo>({
            query: (todo: ITodo) => ({
                url: `/todos/${todo.todoId}`,
                method: 'DELETE',
                body: todo
            }),
            invalidatesTags: ['Todo']
        })
    })
})