import React from "react";
import {SortDown, SortUp} from "react-bootstrap-icons";
import {ISortParams} from "../models/todo/todo.types";

interface ISort {
    field: string
    sort: ISortParams | undefined,
    setSort: (sort: ISortParams) => void
}

const SortPanel: React.FC<ISort> = ({field, sort, setSort}) => {
    return (<>
        <SortUp className="ms-2" style={{color:  sort && sort[field] === 'asc' ? '#fff' : '#aaa'}} onClick={() => setSort({[field]: 'asc'})}/>
        <SortDown className="ms-1" style={{color: sort && sort[field] === 'desc' ? '#fff' : '#aaa'}} onClick={() => setSort({[field]: 'desc'})}/>
    </>)
}

export default SortPanel;