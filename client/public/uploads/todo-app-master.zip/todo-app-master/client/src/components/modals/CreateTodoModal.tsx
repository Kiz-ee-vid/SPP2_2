import React, {ChangeEvent, useState} from "react";
import Modal from "react-bootstrap/Modal";
import {Button} from "react-bootstrap";
import {formatDate, prepareFormData} from "../../utils/converter";
import {ITodo} from "../../models/todo/ITodo";
import {todoAPI} from "../../services/TodoService";
import {showToast, ToastReason} from "../../utils/showToast";
import {TodoErrorValidationResponse} from "../../models/todo/todo.types";
import {FetchBaseQueryError} from "@reduxjs/toolkit/query";
import FileUpload from "../FileUpload";

type CreateTodoModalProps = {
    show: boolean,
    onHide(): void
}

const CreateTodoModal: React.FC<CreateTodoModalProps> = (props) => {
    const {onHide} = props;
    const [createTodo, {error}] = todoAPI.useCreateTodoMutation();

    const [todo, setTodo] = useState<ITodo>({});
    const [file, setFile] = useState<File | null>(null);

    const createTodoHandler = async () => {
        const body = file ? prepareFormData(todo, file) : todo;

        await createTodo({body})
            .unwrap()
            .then(onSuccess)
            .catch((error) => onError(error))
    }

    const onSuccess = () => {
        showToast('Todo created successfully', ToastReason.SUCCESS);
        setTodo({});
        onHide();
    }

    const onError = (error: FetchBaseQueryError) => {
        const data = error.data as TodoErrorValidationResponse;

        showToast(data.message);

        for (const [key, value] of Object.entries(data.errors)) {
            const errorElement = document.getElementById(key);
            if (errorElement) {
                errorElement.innerText = value;
            }
        }
    }

    const onInputChangeHandler = (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setTodo(prev => {
            return {...prev, [event.target.name]: event.target.value}
        })
    }

    return (<>
        <Modal
            {...props}

            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Create Todo
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className="d-flex flex-column mb-3">
                    <label htmlFor="description" className="required col-form-label">Description</label>
                    <textarea className="form-control" name="description"
                              onChange={event => onInputChangeHandler(event)}
                              value={todo?.description}
                              required>{}</textarea>
                    {error &&
                    <div id="description" className="align-self-end text-danger pt-1">{}</div>}
                </div>
                <div className="d-flex flex-column mb-3">
                    <label htmlFor="deadline" className="required col-form-label">Deadline</label>
                    <input type="date" className="form-control" name="deadline"
                           onChange={event => onInputChangeHandler(event)}
                           value={formatDate(todo?.deadline!)}/>
                    {error &&
                    <div id="deadline" className="align-self-end text-danger pt-1">{}</div>}
                </div>
                <FileUpload onChange={setFile}/>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="danger" onClick={onHide}>Close</Button>
                <Button variant="success" onClick={createTodoHandler}>Create</Button>
            </Modal.Footer>
        </Modal>
    </>);

}

export default CreateTodoModal;