export default {
    port: 5000,
    host: "localhost",
    dbUri: "mongodb+srv://mongo:123QWEasd!@cluster0.nxmbp.mongodb.net/todos?retryWrites=true&w=majority"
}