type SortDirection = 'asc' | 'desc';

export interface ISortParams {
    [field: string]: SortDirection
}

export type findOptions = {
    skip?: number,
    limit?: number,
    sort?: ISortParams
}

export interface IFilterParams {
    filterQuery?: string,
    showInProgress?: boolean,
    showCompleted?: boolean,
    showOverdue?: boolean
}
