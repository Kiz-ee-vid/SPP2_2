import {object, string, date} from "yup";

const params = {
    params: object({
        todoId: string().required("Id is required"),
    })
};

const payload = {
    body: object({
        description: string().required("Description is required"),
        deadline: date().required("Deadline is required")
    })
};

export const createTodoSchema = object({
    ...payload
})

export const updateTodoSchema = object({
    ...params,
    ...payload
});

export const deleteTodoSchema = object({
    ...params
});